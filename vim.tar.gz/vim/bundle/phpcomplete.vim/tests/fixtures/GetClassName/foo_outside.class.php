<?php
class FooClass {

}

$this->
self::
