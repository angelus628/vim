<?php
namespace NS31/SubNS;

class Level31 {

	public function level31Method() {
	}

}


?>


