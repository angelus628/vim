<?php
namespace NS3\SubNS;

use NS31\SubNS\Level31;

class Level3 {

	protected function level3Method_protected() {
		// 
	}


	public function level3Method_public() {
	}

	/**
	 * Getting a level31 instance.
	 *
	 * @return Level31
	 */
	public function getLevel31Instance() {
	
	}


	/**
	 * Getting another level31 instance.
	 *
	 * @return NS31\SubNS\Level31
	 */
	public function getAnother31Instance() {
	}

}


?>


