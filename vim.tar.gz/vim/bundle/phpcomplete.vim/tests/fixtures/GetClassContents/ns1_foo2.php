<?php
namespace NS1;

class NamespacedFoo2 extends \NS2\NamespacedFoo {}
