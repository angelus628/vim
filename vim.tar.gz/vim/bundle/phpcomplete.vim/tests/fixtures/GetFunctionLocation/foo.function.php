<?php

function foo(){

}

function FOO2 ()
{

}
