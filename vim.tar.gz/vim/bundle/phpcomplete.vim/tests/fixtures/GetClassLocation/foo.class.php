<?php

class Foo {

    public function bar() {

    }
}

// leading whitespace intentional
 final class Foo2 {

    function bar2() {

    }
 }
