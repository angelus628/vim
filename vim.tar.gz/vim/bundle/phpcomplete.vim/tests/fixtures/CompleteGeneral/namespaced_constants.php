<?php
namespace NS1;

define('ZAP', 42);

namespace NS1\SUBNS;
define('ZAPSUB', 6 * 7);

namespace NS1\SUBNS\SUBSUBNS;
define('ZAPSUBSUB', 2 * 3 * 7);
